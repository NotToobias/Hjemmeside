<div class="main-container">
        <div class="left">
            <h1>Lav et opslag</h1>
            <form id="opslagForm">
                <input type="text" name="navn" placeholder="Dit navn" required><br><br>
                <textarea name="tekst" placeholder="Din besked" required></textarea><br><br>
                <input type="file" name="billede" accept="image/*"><br><br>
                <button type="submit">Opslå</button>
            </form>
        </div>
        <div class="right">
            <h2>Opslag:</h2>
            <div id="opslagContainer">
                <!-- Her vises opslagene senere -->
            </div>
        </div>
    </div>
    

</body>

   



</html>
