<div class="countdown-container">
        <h2>Nedtælling til Halloween</h2>
        <div class="countdown-box">
            <span class="number" id="days1">00</span>
            <span class="label">dage</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="hours1">00</span>
            <span class="label">timer</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="minutes1">00</span>
            <span class="label">min</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="seconds1">00</span>
            <span class="label">sek</span>
        </div>
    </div>

    <div class="countdown-container">
        <h2>Nedtælling til min juleferie</h2>
        <div class="countdown-box">
            <span class="number" id="days2">00</span>
            <span class="label">dage</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="hours2">00</span>
            <span class="label">timer</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="minutes2">00</span>
            <span class="label">min</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="seconds2">00</span>
            <span class="label">sek</span>
        </div>
    </div>

    <div class="countdown-container">
        <h2>Nedtælling til min fødselsdag</h2>
        <div class="countdown-box">
            <span class="number" id="days3">00</span>
            <span class="label">dage</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="hours3">00</span>
            <span class="label">timer</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="minutes3">00</span>
            <span class="label">min</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="seconds3">00</span>
            <span class="label">sek</span>
        </div>
    </div>

    <div class="countdown-container">
        <h2>Nedtælling til juleaften</h2>
        <div class="countdown-box">
            <span class="number" id="days4">00</span>
            <span class="label">dage</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="hours4">00</span>
            <span class="label">timer</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="minutes4">00</span>
            <span class="label">min</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="seconds4">00</span>
            <span class="label">sek</span>
        </div>
    </div>

    <div class="countdown-container">
        <h2>Nedtælling til Nytår</h2>
        <div class="countdown-box">
            <span class="number" id="days5">00</span>
            <span class="label">dage</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="hours5">00</span>
            <span class="label">timer</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="minutes5">00</span>
            <span class="label">min</span>
        </div>
        <div class="countdown-box">
            <span class="number" id="seconds5">00</span>
            <span class="label">sek</span>
        </div>
    <script src="javascript/nedtaelling.js"></script>
    
    


</body>

   



</html>
