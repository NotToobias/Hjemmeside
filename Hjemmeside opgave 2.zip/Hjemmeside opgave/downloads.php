
    <div class="container">
        <h1>Downloads</h1>
        
        <div class="buttons-section">
            <a href="/lectio" class="button">Fravær på lectio skema</a>
            <a href="" class="button">Kommer snart!</a>
            <a href="" class="button">Kommer snart!</a>
        </div>
    </div>

</body>




</html>
