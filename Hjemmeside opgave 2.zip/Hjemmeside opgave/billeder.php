    <div class="container">
        <h1>Billede samling</h1>
        
        <div class="buttons-section">
            <a href="/tyskland2021" class="button">Tyskland studietur 2021</a>
            <a href="/rom2023" class="button">Rom studietur 2023</a>
            <a href="/amsterdam2025" class="button">Amsterdam studietur 2025</a>
        </div>
    </div>

</body>

   



</html>
