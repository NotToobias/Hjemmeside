<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tobias' Website</title>
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <?php if ($file == 'password') : ?>
    <link rel="stylesheet" href="css/stylepassword.css">
<?php else : ?>
    <link rel="stylesheet" href="css/main.css">
<?php endif; ?>



</head>
<body>
    <div class="navbar">
        <!-- Navigation Bar -->
        <div class="navigationsbar">
        <ul>
    <li><a href="/" <?php if ($file == 'index') echo 'class="active"'; ?>>Forside</a></li>
    <li><a href="billeder" <?php if ($file == 'billeder' || $file == 'tyskland2021' || $file == 'rom2023' || $file == 'amsterdam2025') echo 'class="active"'; ?>>Billeder</a></li>
    <li><a href="mcd" <?php if ($file == 'mcd') echo 'class="active"'; ?>>Vigtigste sted</a></li>
    <li><a href="game" <?php if ($file == 'game') echo 'class="active"'; ?>>Spil</a></li>
    <li><a href="nedtaelling" <?php if ($file == 'nedtaelling') echo 'class="active"'; ?>>Nedtælling</a></li>
    <li><a href="downloads" <?php if ($file == 'downloads' || $file == 'lectio') echo 'class="active"'; ?>>Downloads</a></li>
    <li><a href="password" <?php if ($file == 'password' || $file == 'om') echo 'class="active"'; ?>>Om</a></li>

</ul>




        </div>

        <!-- Burger Menu Icon (Only visible on mobile) -->
        <div class="burger-menu" onclick="toggleMenu()">☰</div>
    </div>
    

    
    <div class="copyright">
        &copy; Erkeby.com <span id="year"></span>


        <script>
            document.getElementById("year").textContent = new Date().getFullYear();
        </script>
    </div>
    <div class=domain>
        Domænenavnet Erkeby.com er ikke til salg
        
    </div>
    
    <div class="links">
    <!-- Links i bunden -->
    <a href="https://www.instagram.com/Tobias_erkeby">
        <img src="images/instagram-icon.png" alt="Instagram Icon" style="width: 20px; vertical-align: middle; margin-right: 5px;"> Instagram
    </a>
    <a href="https://www.snapchat.com/add/Tobias_erkeby">
        <img src="images/snapchat-icon.png" alt="Snapchat Icon" style="width: 20px; vertical-align: middle; margin-right: 5px; border-radius: 20%;" > Snapchat
    </a>
    <a href="https://www.tiktok.com/@Tobias_erkeby">
        <img src="images/tiktok-icon.ico" alt="TikTok Icon" style="width: 20px; vertical-align: middle; margin-right: 5px;"> TikTok
    </a>
</div>


    <!-- Include the JavaScript file for menu toggle functionality -->
    <script src="javascript/header.js"></script>
</body>
</html>
