document.getElementById("passwordForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevents the page from reloading
    checkPassword();
});

function checkPassword() {
    const passwords = ["john", "informatik", "kode"]; // Enter your passwords here
    const input = document.getElementById("passwordInput").value;
    const message = document.getElementById("message");

    if (passwords.includes(input)) {
        window.location.href = "/om"; // Redirect to the "om" page without .php
    } else {
        message.textContent = "Forkert kode. Prøv igen.";
        message.style.color = "red";
    }
}
