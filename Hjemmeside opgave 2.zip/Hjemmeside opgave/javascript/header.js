// header.js

function toggleMenu() {
    const navLinks = document.querySelector('.navigationsbar');
    navLinks.classList.toggle('active');
}

