<?php
// Get the requested URL path and trim any leading or trailing slashes
$request = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');

// If no specific path is requested, default to "index"
$file = $request === '' ? 'index' : $request;

// Include the header with navigation before loading the page content
include_once 'header.php';

// Debugging
echo "<!-- Requested file: $file -->";
// Define the PHP file to load
$page = "$file.php";

// Check if the PHP file exists and include it
if (file_exists($page)) {
    include $page;
} else {
    // Handle 404 error if the file does not exist
    http_response_code(404);
    echo "404 - Page not found";
    exit;
}
?>
