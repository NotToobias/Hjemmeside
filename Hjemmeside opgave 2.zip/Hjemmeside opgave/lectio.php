 <body>

        <div class="container"> <!--Samling-->
        
            <h1>Lectio fravær på skema</h1>
            <img src="images/lectiofravaer2.png" style="width: 100%;" alt="Lectio fravær">
            <a href="download/Fravær UNZIP MIG.zip" download="UNZIP MIG" class="button">Lectio Fravær Addon</a>
            </div>
        <!-- Indlejret video -->
        <iframe width="560" height="315" src="https://www.youtube.com/embed/hAC3RrdauIc?si=5WhPeXJCLKeaoLJ8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen="true"></iframe>   
    </body>

</body>




</html>
