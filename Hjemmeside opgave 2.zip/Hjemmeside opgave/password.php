<style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height: 100vh;
    background-color: #202223; /* Grå baggrund */
    color: #c8c3bc;
}

.navbar {
    width: 100%;
    background-color: #181a1b;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    margin-bottom: 40px; /* Added space below the navbar */
}


.navigationsbar {
    display: flex;
    gap: 20px;
}

.navigationsbar ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
    display: inline-flex;
}

.navigationsbar a {
    color: #7a00cc;
    text-decoration: none;
    font-weight: bold;
    padding: 10px 15px;
    line-height: 1.5;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.navigationsbar a.active {
    background-color: #5b2d82;
    color: white;
    border-radius: 5px;
}

.burger-menu {
    display: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #7a00cc;
    margin-left: auto; /* Push the burger menu to the far right */
}

@media (max-width: 768px) {
    .navigationsbar {
        display: none; /* Hide menu bar on mobile */
        flex-direction: column;
        position: absolute;
        top: 60px;
        right: 0;
        background-color: #181a1b;
        width: 100%;
        padding: 10px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .navigationsbar.active {
        display: flex; /* Show the menu when active on mobile */
    }

    .burger-menu {
        display: block; /* Show the burger icon on smaller screens */
    }

    .navigationsbar ul {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }

    .navigationsbar a {
        width: 100%;
        padding: 15px;
        text-align: left;
    }

    .navigationsbar a.active {
        background-color: #5b2d82;
        color: white;
    }
}
.container { 
    max-width: 600px;
    background: #181a1b;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
    margin-bottom: 40px;
}
.copyright {
    width: 100%;
    position: fixed;
    bottom: 10px;
    right: 10px;
    left: 10px;
    text-align: left;
    
}
.domain {
    width: 100%;
    position: fixed;
    bottom: 30px;
    right: 10px;
    left: 10px;
    text-align: left;
    
}
/* Footer links */
.links {
    width: 100%;
    position: fixed;
    bottom: 10px;
    right: 10px;
    text-align: right;
}

.links a {
    margin-left: 20px;
    color: #7a00cc;
    text-decoration: none;
    font-weight: bold;
}

.links a:hover {
    text-decoration: underline;
}


input {
    padding: 10px;
    margin: 10px 0;
    width: 100%;
    max-width: 300px;
}

button {
    padding: 10px;
    cursor: pointer;
    background-color: #7a00cc;
    color: white;
    border: none;
    border-radius: 4px;
}

</style>
<body>
    <div class="container">

        <h1>Halløj. Her finder du min blå bog</h1>
        <p>Skriv kodeordet for at fortsætte:</p>
        <form id="passwordForm">
            <input  type="password" id="passwordInput" placeholder="Skriv kodeordet">
            <button type="submit">Indsend</button>
        </form>
        <p id="message"></p>
    </div>
    <script src="javascript/passwordscript.js"></script>
</body>
</html>

