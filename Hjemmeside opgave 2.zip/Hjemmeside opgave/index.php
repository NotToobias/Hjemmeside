<?php
$file = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME);
?>


<?php include 'header.php'; ?> 

<div class="container">
    <h1>Velkommen til min hjemmeside!</h1>
    <img src="images/hi.gif" alt="Vinke" class="vinke">
</div>


