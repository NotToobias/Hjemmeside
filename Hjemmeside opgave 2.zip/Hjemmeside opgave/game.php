
    <!-- Iframe -->
    </div> 
    <main>
        <iframe width="10000" height="10000" src="spil/John.html" frame-border="20"border-radius="20%" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"></iframe>
    </main>
  
    </body>
    </html>