<div class="container"> <!--Samling-->
        
        <img src="images/lectiobillede.jfif" alt="Tobias' lectiobillede" class="lectiobillede"> 
        <h1>Tobias' Blå bog</h1>
         <div class="info"> <!--Alt infoen-->
             <p><b>Fulde navn: </b>John <b><u>Tobias</u></b> Erkeby Larsen</p>
            <p><b>Kaldenavn: </b>John Bøf, Bøf John, Store John, Jihn, John. m.fl. </p>
             <p><b>Bopæl: </b>Knastebakken 249, 2750 Ballerup</p>
             <p><b>Interesser: </b>Kommer snart...</p>
             <p><b>Fun facts: </b>Kommer snart...</p>
            <p><b>Andet: </b>Kommer måske???</p>
        </div>
    </div>

</body>




</html>
