<body>
        <h1>Tyskland billeder</h1>
        <div class="collage-container">
            <a href="#lightbox1"><img src="images/tyskland/tysklandbillede1.jpeg" alt="Image 1"></a>
            <a href="#lightbox2"><img src="images/tyskland/tysklandbillede2.jpeg" alt="Image 2"></a>
            <a href="#lightbox3"><img src="images/tyskland/tysklandbillede3.jpeg" alt="Image 3"></a>
            <a href="#lightbox4"><img src="images/tyskland/tysklandbillede4.jpeg" alt="Image 4"></a>
            <a href="#lightbox5"><img src="images/tyskland/tysklandbillede5.jpeg" alt="Image 5"></a>
            <a href="#lightbox6"><img src="images/tyskland/tysklandbillede6.jpeg" alt="Image 6"></a>
        </div>
    
        <!-- Lightbox popups -->
        <div id="lightbox1" class="lightbox" onclick="closeLightbox()">
            <a href="#" class="close">&times;</a> <!-- Close button -->
            <img src="images/tyskland/tysklandbillede1.jpeg" alt="Image 1">
        </div>
        
        <div id="lightbox2" class="lightbox" onclick="closeLightbox()">
            <a href="#" class="close">&times;</a> <!-- Close button -->
            <img src="images/tyskland/tysklandbillede2.jpeg" alt="Image 2">
        </div>
        
        <div id="lightbox3" class="lightbox" onclick="closeLightbox()">
            <a href="#" class="close">&times;</a> <!-- Close button -->
            <img src="images/tyskland/tysklandbillede3.jpeg" alt="Image 3">
        </div>
        
        <div id="lightbox4" class="lightbox" onclick="closeLightbox()">
            <a href="#" class="close">&times;</a> <!-- Close button -->
            <img src="images/tyskland/tysklandbillede4.jpeg" alt="Image 4">
        </div>
        
        <div id="lightbox5" class="lightbox" onclick="closeLightbox()">
            <a href="#" class="close">&times;</a> <!-- Close button -->
            <img src="images/tyskland/tysklandbillede5.jpeg" alt="Image 5">
        </div>
        
        <div id="lightbox6" class="lightbox" onclick="closeLightbox()">
            <a href="#" class="close">&times;</a> <!-- Close button -->
            <img src="images/tyskland/tysklandbillede6.jpeg" alt="Image 6">
        </div>
        <script src="javascript/billeder.js"></script>
</body>

   



</html>
