const images = [];
let isSliderActive = false;
let isMouseDown = false;
let spawnInterval;
let mouseX = 0;
let mouseY = 0;
let speedFactor;
let mouseDownTimer = 0;
speedFactor = typeof speedFactor !== 'undefined' ? speedFactor : 3;
const navbarHeight = document.querySelector('.navbar').offsetHeight;
let isDropdownActive = false;
let currentImageX = 257;
let currentImageY = 203;

document.getElementById('speedSlider').addEventListener('mousedown', () => {
    isSliderActive = true;
    console.log("applying speed factor:", speedFactor)
});



document.getElementById('speedSlider').addEventListener('mouseup', () => {
    isSliderActive = false;
});

document.getElementById('speedSlider').addEventListener('input', (event) => {
    speedFactor = event.target.value;
    setCookie('speedFactor', speedFactor, 200000);
});
document.addEventListener('mousedown', (event) => {
    if (isSliderActive) return;
    if (isDropdownActive) return;
    if (cookiePopupActive) return;
    if (!imageActive) return;
    isMouseDown = true;
    const x = event.clientX - currentImageX / 2;
    const y = event.clientY - currentImageY / 2;
    if (event.clientY <= navbarHeight) return;
    createImage(x, y);



mouseDownTimer = setTimeout(() => {
    if (isMouseDown) {
        createImage(mouseX, mouseY);
        spawnInterval = setInterval(() => createImage(mouseX, mouseY), 10);
    }
}, 150);
});


document.addEventListener('mouseup', () => {
    isMouseDown = false;
    clearTimeout(mouseDownTimer);
    clearInterval(spawnInterval);
});
document.addEventListener('mousemove', (event) => {
    mouseX = event.clientX - currentImageX/2;
    mouseY = event.clientY - currentImageY/2;
});
function createImage(x, y) {
    if (cookieConsent == false) return;
    if (isSliderActive) return;
    const createImg = document.createElement('img');
    createImg.src = imageActive;
    createImg.className = "image";

    let dx = Math.random() * 6 - 3;
    let dy = Math.random() * 6 - 3;
    let angle = 0;
    createImg.draggable = false;
    createImg.style.left = `${x}px`;
    createImg.style.top = `${y}px`;
    document.body.appendChild(createImg);

    images.push({ element: createImg, x, y, dx, dy, angle });

    rotateAndMove(images[images.length - 1]);
}
document.addEventListener('contextmenu', (event) => {
    event.preventDefault();
});

function rotateAndMove(imageData) {
    imageData.angle += Math.random() * speedFactor / 5;

    imageData.element.style.transform = `rotate(${imageData.angle}deg)`;

    imageData.x += imageData.dx * speedFactor / 4;
    imageData.y += imageData.dy * speedFactor / 4;

    if (imageData.x <= 0 || imageData.x >= window.innerWidth - currentImageX) {
        imageData.dx = -imageData.dx;
    }
    if (imageData.y <= navbarHeight || imageData.y >= window.innerHeight - currentImageX) {
        imageData.dy = -imageData.dy;
    }

    imageData.element.style.left = `${imageData.x}px`;
    imageData.element.style.top = `${imageData.y}px`;

    requestAnimationFrame(() => rotateAndMove(imageData));
}

