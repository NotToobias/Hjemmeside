function imageSwitchDropDown() {
    document.getElementById("dropdown").classList.toggle("show");
    if (isDropdownActive) isDropdownActive = false;
    else isDropdownActive = true;
}

window.onclick = function (event) {
    if (!event.target.matches('.imagebutton')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
                if (isDropdownActive) isDropdownActive = false;
            }
        }
    }
} //click outside dropdown cancel

function imageSwitch(w, h, iw, ih, img) {
    currentImageX = w;
    currentImageY = h;
    imageActive = img;
    document.getElementById("imagebuttonsrc").src = imageActive;
    document.getElementById("imagebuttonsrc").width = iw;
    document.getElementById("imagebuttonsrc").height = ih;
    setCookie('selection', img, 235035);
    console.log("cookie sat:", img);
} //switch active image to the one pressed in dropdown