let cookieConsent;
let cookiePopupActive;
let imageActive = "";
function getCookie(name) {
    const decodedCookie = decodeURIComponent(document.cookie);
    const ca = decodedCookie.split(';');
    const cookieName = `${name}=`;
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(cookieName) === 0) {
            return c.substring(cookieName.length, c.length);
        }
    }
    return "";
}

function parseCookies() {
    const cookieString = document.cookie;
    const cookies = cookieString.split(';');
    console.log("COOKIES " + cookies);
    const imageArray = [
        "assets/burger1.webp",
        "assets/kanelstang.webp"
    ];
    console.log("Johns:", imageActive);
    i = 1;
    for (const cookie of cookies) {
        console.log("Lars:", cookie);
        const [name, value] = cookie.split('=').map(c => c.trim());
        console.log(value);
        console.log("Parsed Name:", name, "Parsed Value:", value);  // Log the parsed cookie

        // Log the exact value and check for encoding issues - virker nu 
        console.log("Checking value:", value, "against imageMap keys:", imageArray);
        console.log(typeof (value))
        console.log(typeof (imageArray[1]))
        console.log(imageArray[i], value);
        console.log("Johssndf:", value);
        for (let i = 0; i < imageArray.length; i++) {
            if (imageArray[i] === value) {
                console.log("Johssn:", value);
                imageActive = value;
                const img = new Image();
                img.src = imageActive;
                console.log("John:", imageActive);
                document.getElementById("imagebuttonsrc").src = imageActive;

                img.onload = function () {
                    currentImageX = img.width;
                    currentImageY = img.height;
                }
                break; // ud af loopet n�r den er f�rdig og videre til n�ste cookie
            } else {
                console.log("Failed imageMap", value, "=", cookie, "/", imageArray);
            }
        }
    }
}




window.onload = () => {
    const consentGiven = getCookie('cookieConsent');
    const selection = getCookie('selection');
    if (consentGiven !== 'true') {
        document.getElementById('simple-cookie-consent').style.display = 'flex';
        cookiePopupActive = true;
    } else {
        loadSliderValue();
        document.getElementById("simple-cookie-consent").style.display = "none";
        cookieConsent = true;
        cookiePopupActive = false;
    }
    if (selection) {
        parseCookies();
    } else {
        setCookie('selection', 'burger1', 905348);
        imageActive = 'assets/burger1.webp';
        currentImageX = 257;
        currentImageY = 203;
        console.log('imageactive:', imageActive);
    }
};

document.getElementById('acceptCookies').addEventListener('click', () => {
    setCookie('cookieConsent', 'true', 200000);
    cookieConsent = true
    cookiePopupActive = false;
    document.getElementById('simple-cookie-consent').style.display = 'none';
    loadSliderValue();
});

document.getElementById('denyCookies').addEventListener('click', () => {
    window.close();
});
function loadSliderValue() {
    const savedSpeed = getCookie('speedFactor');
    if (savedSpeed) {
        speedFactor = parseInt(savedSpeed, 10);
        document.getElementById('speedSlider').value = speedFactor;
    }
}
function setCookie(name, value, days) {
    const d = new Date();
    d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
    const expires = "expires=" + d.toUTCString();
    document.cookie = `${name}=${value}; ${expires}; path=/; SameSite=Lax`;
}